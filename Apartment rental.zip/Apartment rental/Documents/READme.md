HOMEpage
•  Changelog: 
•	Part 1 Initial Setup: Created the base HTML structure for the "Your Home" webpage, including header with navigation (links to Apartment rentals, View, Features, Pricing, Company, Resources, sign in, and Let's Talk), a main section with a "Discover your new Home" heading and image, and a footer with Help, About, and Contact sections.
•	Feedback Edits from Part 1: (If you received feedback, let me know, and we can add specific edits here; otherwise, this can remain placeholder.)
•	Part 2 Enhancements: Added SEO meta tags, custom CSS for styling (reset, typography, header, main, footer, modal), JavaScript for modal functionality, and social media links (Facebook, Twitter, Instagram).
•  References: 
•	HTML and CSS basics from w3schools.com.
•	Font Awesome for social icons from cdnjs.com.
•	General web development resources.

MYCOMPANY
•	New Information Pertinent to Part 2: Enhanced the "Company" page for "Your Home" with SEO meta tags (description, keywords, viewport), a custom CSS stylesheet for responsive design, typography, and layout, added sections for company history, mission, team profiles with images, a contact form, and an updated footer with social media links (Facebook, Twitter, Instagram).
•	Changelog: 
o	Part 1 Initial Setup: Created a basic HTML structure for the "Company" page, including a heading ("About Our Company"), a description of over 10 years of managing premium rental apartments, and a back link to the home page.
o	Feedback Edits from Part 1: (Add any specific feedback edits here if applicable; otherwise, this can remain placeholder.)
o	Part 2 Enhancements: Added CSS for styling (reset, typography, sections, contact form), JavaScript for form submission (via PHP placeholder), team member profiles with images, and a timestamp for last update.
•	References: 
o	HTML and CSS basics from w3schools.com.
o	Font Awesome for social icons from cdnjs.com.

Features
•	Changelog: 
o	Part 1 Initial Setup: Created a basic HTML structure for the "Features" page, including a heading ("Features"), a list of amenities (rooftop deck, gym, pet-friendly, smart home technology, high-speed WiFi), and a back link to the home page.
o	Feedback Edits from Part 1: (Add any specific feedback edits here if applicable; otherwise, this can remain placeholder.)
o	Part 2 Enhancements: Added CSS for styling (reset, typography, feature grid, contact form), a timestamp for last update, and integrated a contact form with a placeholder for form submission (via PHP).
•	References: 
o	HTML and CSS basics from w3schools.com.
o	Font Awesome for social icons from cdnjs.com.

PRICING
